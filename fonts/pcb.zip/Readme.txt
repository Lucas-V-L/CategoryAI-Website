Printed Circuit Board Font

The Printed Circuit Board font is based on the HP logo. It contains alphanumeric symbols, punctuation, currency symbols and international characters. It comes in Regular and Italic, the latter is 20 degrees slanted. Press Alt+1 to get the 1954 HP logo.

JLH Fonts Terms of Use

Version 1.1

You must read the terms of use carefully before using any font made by JLH Fonts ("Font").

1. Acceptance of Terms

By using any Font, you agree to all the terms contained herein.

2. Use of Fonts

When you download a Font, you agree to use the Font provided that you abide by the following: a) all Fonts are in the public domain (as noted on the Font's copyright notice), which means that you can use a Font for any purpose whatsoever; b) you are free to reproduce, edit or use any other means of modificiation of this Font; and c) you are free to distribute this Font. All Fonts are created and exported with FontLab software and are available as TrueType (.ttf) or OpenType (.otf) formats. Some fonts come with a Readme file with a license agreement; read it.

3. Discontinuation or Revision of Fonts

JLH Fonts reserves the right to edit, reclaim, delete or otherwise discontinue or revise any Font at any time for any reason.

4. Installing a Font

You can install a font on an unlimited number of devices (computer, phone, PDA, tablet, etc.). By installing a font, you agree to all of the aforementioned Terms. If you do not, you must delete this font.